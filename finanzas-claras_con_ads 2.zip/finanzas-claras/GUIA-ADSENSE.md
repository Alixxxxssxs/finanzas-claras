# Guía paso a paso: publicar Finanzas Claras y conseguir la aprobación de AdSense

## 1. Por qué este nicho es más rentable (y más exigente)
Finanzas personales está entre las categorías con **mayor CPC** en AdSense: anunciantes de bancos, seguros, tarjetas de crédito y fintech pagan considerablemente más por clic que la mayoría de los nichos de entretenimiento o lifestyle. A cambio, Google clasifica este contenido como **YMYL** ("Your Money or Your Life"): información que puede afectar el bienestar financiero de las personas, y por eso aplica un estándar de calidad más alto tanto para la aprobación de AdSense como para el posicionamiento en búsquedas.

## 2. Lo que ya está resuelto en este sitio
- ✅ 20 artículos originales y explicativos (no genéricos ni copiados).
- ✅ Aviso legal/disclaimer en cada artículo y reforzado en "Sobre nosotros" y "Privacidad" — Google valora que el contenido financiero deje claro que es educativo, no asesoría personalizada.
- ✅ Política de privacidad con las cláusulas de cookies y AdSense.
- ✅ Estructura de navegación clara por categorías (Ahorro, Crédito, Inversión, Seguros, Deudas, etc.).

## 3. Lo que te falta antes de solicitar AdSense
- [ ] **Agregar información de autoría (E-E-A-T).** Para contenido YMYL, Google valora mucho ver quién escribe: agrega una breve bio del autor/a en "Sobre nosotros" (o en cada artículo) que hable de experiencia o interés genuino en el tema. No necesitas ser un asesor certificado, pero la transparencia ayuda mucho.
- [ ] Reemplaza los correos y textos entre corchetes `[...]` en `contacto.html` y `politica-privacidad.html` por tus datos reales.
- [ ] Conecta el formulario de contacto a un servicio real (Formspree, EmailJS, etc.).
- [ ] Revisa cualquier cifra o ejemplo numérico de los artículos: son ilustrativos, no datos de mercado en tiempo real — mantenlos como ejemplos genéricos, no los presentes como recomendaciones de inversión concretas.
- [ ] Verifica velocidad de carga en [PageSpeed Insights](https://pagespeed.web.dev/).
- [ ] Deja el sitio en línea con contenido estable durante 2-4 semanas antes de solicitar revisión.

## 4. Dominio y hosting
1. Registra un dominio (ej. `finanzasclaras.com`) en Namecheap, GoDaddy, etc. (10-15 USD/año).
2. Sube el sitio a **Netlify** o **Vercel** (gratis, ideal para HTML estático): arrastra la carpeta `finanzas-claras/` completa en "Deploy manually" y conecta tu dominio en "Domain settings".

## 5. Solicita la cuenta de AdSense
1. Ve a [google.com/adsense](https://www.google.com/adsense) con tu dominio ya activo.
2. Pega el código de verificación de Google en el `<head>` de todas las páginas del sitio.
3. Envía la solicitud. Para nichos YMYL, la revisión puede tardar más que en nichos genéricos — ten paciencia.

## 6. Motivos de rechazo específicos de este nicho
- **"Contenido insuficiente o de bajo valor"**: en finanzas, Google es más estricto. Considera ampliar los 20 artículos con casos prácticos o ejemplos numéricos claramente marcados como ilustrativos.
- **"Contenido engañoso o sin respaldo"**: evita cualquier afirmación tipo "esta inversión te hará rico" o cifras de rendimiento prometidas — el tono educativo y con matices (como el de los artículos incluidos) es justamente lo que reduce este riesgo.
- **Falta de transparencia sobre quién escribe**: agrega la información de autoría mencionada en el punto 3.

## 7. Una vez aprobado
1. Sustituye cada `<div class="ad-slot">...</div>` por el bloque de anuncio real que te dé AdSense.
2. Para finanzas, ten cuidado especial con la ubicación de anuncios: evita que un anuncio de un producto financiero real (ej. una tarjeta de crédito) aparezca pegado a contenido que advierte sobre los riesgos de ese mismo tipo de producto — puede generar una sensación de conflicto de interés en el lector, aunque tú no controles qué anuncio específico se muestra.
3. Considera afiliados financieros (comparadores de tarjetas, seguros, cuentas de ahorro) como ingreso complementario a AdSense — muchos de estos programas de afiliados también pagan comisiones altas en este nicho, aunque requieren solicitud y aprobación aparte de cada programa.

---
**Nota:** en nichos financieros, la reputación y la señal de "contenido confiable" pesan más que en otros. Mantener un tono equilibrado (mostrando riesgos y beneficios, como en los artículos incluidos) no solo cumple mejor las políticas de Google, sino que genera más confianza real en los lectores — lo cual, a largo plazo, se traduce en más tráfico recurrente y mejor monetización.
